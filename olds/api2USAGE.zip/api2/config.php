<?php
/**
 * Common configuration
 */

$config = [
    'client_id' => "55493798955-olcchs77135pb7hu1a758uod4bsl332r.apps.googleusercontent.com",
    'client-secret' => "Iq0yM00-xLMfg7DG6CuD4cCR",
];
$headers=array('Authorization' => "Bearer ya29.dQKn3wdHVRgDcOJzGmDSPCfjZD4vNbc1rWYsX6KNfTbwUEdtB_W15rLJXZsNjikhr9GE");
