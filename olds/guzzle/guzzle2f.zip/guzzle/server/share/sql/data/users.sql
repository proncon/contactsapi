INSERT INTO `users` (`email`,`apikey`) VALUES ("me@example.com", "MyVeryLongAPIKey");
