<?php

require_once 'vendor/autoload.php';
$contacts = rapidweb\googlecontacts\factories\ContactFactory::getAll();

//var_dump($contacts);