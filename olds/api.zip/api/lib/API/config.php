<?php
/**
 * Common configuration
 */

$config = [
    'client_id' => "55493798955-olcchs77135pb7hu1a758uod4bsl332r.apps.googleusercontent.com",
    'client-secret' => "Iq0yM00-xLMfg7DG6CuD4cCR",
];
$headers=array('Authorization' => "Bearer ya29.dAIfsLg22KlB2arftmWmW3XGSCKi7rt_QQF7M4nKT_k2t44RLl2t1YtNaKfd4G3_bCbY");

$dbconfig = [
    'database_type' => 'mysql',
    'database_name' => 'contactsapi',
    'server' => 'localhost',
    'username' => 'dev',
    'password' => '12345678',
    'charset' => 'utf8'
];

$candidate="paulo";