<?php
/**
 * Common configuration
 */

$config = [
    'client_id' => "55493798955-olcchs77135pb7hu1a758uod4bsl332r.apps.googleusercontent.com",
    'client-secret' => "Iq0yM00-xLMfg7DG6CuD4cCR",
];
$headers=array('Authorization' => "Bearer ya29.dAJS_l1i2YEb9MLFVy3tj7PkGB-bHS0iOgDPOH7XFgghv--Dw5Rc8n7MLRreil76AoIB");

$dbconfig = [
    'database_type' => 'mysql',
    'database_name' => 'contactsapi',
    'server' => 'localhost',
    'username' => 'dev',
    'password' => '12345678',
    'charset' => 'utf8'
];

$candidate="paulo";